/*	author:zou dongyan
**	email:kezonet@gmail.com
**	date:2010/1/1
*/
function Loupe(obj){
	this.small	= obj.small	|| "loupe_small",
	this.big	= obj.big	|| "loupe_big",
	this.img_s	= obj.img_s	|| "loupe/petit.jpg",
	this.img_b	= obj.img_b	|| "loupe/grand.jpg",
	this.mclass	= obj.mclass|| "loup_move",
	this.dd		= obj.dd	|| "right",
	this.auto	= obj.auto	|| false,
	this.fois	= obj.fois	|| 2
	this.init();
}
Loupe.prototype	= {
	init:function(){
		this.s	= {obj:document.getElementById(this.small),img:document.createElement("img")}
		this.b	= {obj:document.getElementById(this.big)}
		this.m	= {obj:document.createElement("div")}
		this.s.img.setAttribute("src",this.img_s);
		this.s.obj.appendChild(this.s.img);
		this.m.obj.setAttribute("class",this.mclass);
		this.m.obj.setAttribute("className",this.mclass);
		this.s.obj.appendChild(this.m.obj);
		this.s.obj.style.position	= 'relative';
		if(this.auto){
			this.s.obj.style.cssFloat	= this.dd;
			this.s.obj.style.styleFloat	= this.dd;
		}
		this.b.width	= parseInt(this.b.obj.style.width);
		this.b.height	= parseInt(this.b.obj.style.height);
		this.b.obj.style.backgroundImage	= "URL("+this.img_b+")";
		this.b.obj.style.backgroundPosition = '0px 0px';
		this.m.width			= this.b.width/this.fois;
		this.m.height			= this.b.height/this.fois;
		this.m.obj.style.width	= this.m.width+'px';
		this.m.obj.style.height	= this.m.height+'px';
		this.m.obj.style.zIndex	= '1000';
		this.m.obj.style.left	= '0px';
		this.m.obj.style.top	= '0px';
		this.m.obj.style.position	= 'absolute';
		this.img_onload();
		this.s.img.onload		= this.bind(this.img_onload,this);
		this.s.obj.onmousedown	= this.bind(this.m_mousedown,this);
	},
	img_onload:function(e){
		if(e == null){e = window.event}
		this.s.img.style.display="block";
		this.s.width			= this.s.img.offsetWidth;
		this.s.height			= this.s.img.offsetHeight;
		this.s.obj.style.width	= this.s.width+'px';
		this.s.obj.style.height	= this.s.height+'px';
		this.diverX				= parseInt(this.s.width-this.m.width);
		this.diverY				= parseInt(this.s.height-this.m.height);
		if(this.s.width){
			this.s.obj.style.backgroundImage= "URL("+this.img_s+")";
			this.s.img.style.display		="none";
		}
	},
	m_mousedown:function(e){
		if(e == null){e = window.event}
		this._x	= e.clientX-parseInt(this.m.obj.style.left);
		this._y	= e.clientY-parseInt(this.m.obj.style.top);
		if(!e.target||e.target==this.m.obj){
			this.s.obj.onmousemove	= this.bind(this.m_mousemove,this);
			this.s.obj.onmouseup	= this.bind(this.m_mouseup,this);
		}
		document.body.focus();
		document.onselectstart	= function () { return false; }
		e.target.ondragstart	= function() { return false; } 
		return false; 
	},
	m_mousemove:function(e){
		if(e == null){e = window.event}
		this.move(parseInt(e.clientX-this._x), parseInt(e.clientY-this._y));
	},
	m_mouseup:function(e){
		if(e == null){e = window.event}
		this.s.obj.onmousemove	= null;
		if(this.auto){this.check(parseInt(e.clientX-this._x), parseInt(e.clientY-this._y));}
		return false; 
	},
	move:function(x,y){
		x	= (x>0)?(x<this.diverX)?x:this.diverX:0;
		y	= (y>0)?(y<this.diverY)?y:this.diverY:0;
		this.m.obj.style.left	= x+'px';
		this.m.obj.style.top	= y+'px';
		this.b.obj.style.backgroundPosition = -x*this.fois+'px '+(-y*this.fois)+'px';
	},
	check:function(x,y){
		if(this.dd=="left"&&x<5||this.dd=="right"&&x>this.diverX-5){
			this.dd	= (this.dd=="left")?"right":"left";
			this.s.obj.style.cssFloat	= this.dd;
			this.s.obj.style.styleFloat	= this.dd;
		}
	},
	bind:function(fn,scope){
		return function(){
			fn.apply(scope,arguments);
		}
	}
}
window.onload=function(){myLoupe = new Loupe({fois:5,small:"petit",big:"grand",img_s:"loupe/petit_5.jpg"});}